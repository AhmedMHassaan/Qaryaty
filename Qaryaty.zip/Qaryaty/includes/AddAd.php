<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$data = json_decode(file_get_contents('php://input'), true);


$images = $data['images'];
$title = $data['TITLE'];
// $statues = $data['STATUS'];
$cat = $data['CAT_ID'];
$details = $data['DETAILS'];
$type = $data['TYPE_ID'];
$userPhone = ($data['user'])['PHONE'];
// $ = $data[''];
// $ = $data[''];
// $ = $data[''];
// $ = $data[''];
// $ = $data[''];


if (isset($title) && ! empty($title)) {
  
  
  
 
  
    $query = "INSERT INTO `ads` (`ADS_ID`, `TITLE`, `STATUS`, `USER_ID`, `CATEGORY_ID`, `DETAILS`, `AD_TYPE_ID`, `AD_TIMESTAMP`, `created_at`, `updated_at`)
    VALUES (
   
    NULL,
    '".$title."',
    NULL,
    (SELECT users.USER_ID FROM users WHERE users.PHONE = '".$userPhone."' ),
    '".$cat."',
    '".$details."',
    NULL,
    current_timestamp(),
    NULL,
    NULL
   
    )
";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $adId = (mysqli_fetch_assoc(mysqli_query($con, " SELECT LAST_INSERT_ID() as N ")))['N'];
        
        for($i=0; $i < sizeof($images) ; $i++){
            
             $r = mysqli_query($con , " INSERT INTO `images` (`IMG_ID`, `AD_ID`, `IMAGE`, `IMG_TYPE`) VALUES (NULL, '".$adId."', '".$images[$i]."', '')");
      
                 if(!r){
                      $response['code']=1;
                      $response['message']= "خطأ أثناء إضافة الصورة  ".$i ;
                      $response['response']= false ;
                      ob_end_clean();
                      echo json_encode($response);
                      return ;
                 }
     
        }
     
      $response['code']=1;
      $response['message']= "تم إضافة االإعلان";
      $response['response']= true;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
//	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "Complete All Required Data ";
}

ob_end_clean();
echo json_encode($response);
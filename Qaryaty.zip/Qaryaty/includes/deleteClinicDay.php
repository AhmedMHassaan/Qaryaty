<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => -1  );
ob_start();

$dayId = $_POST['dayId'];
$pos = $_POST['posInApp'];

if (isset($dayId)) {
  
    $query = "DELETE FROM `clinic_days` WHERE clinic_days.DAY_ID = '".$dayId."' ";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
      $response['code']=1;
      $response['message']= "تم الحذف بنجاح";
      $response['response']= $pos ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
//	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "يرجي اختيار اليوم أولا";
}

ob_end_clean();
echo json_encode($response);
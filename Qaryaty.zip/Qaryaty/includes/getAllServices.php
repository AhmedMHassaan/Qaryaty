<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$dep = $_GET['dep'];

if (isset($dep) && ! empty($dep)) {
  
    $query = "SELECT * FROM services WHERE services.DEPARTMENT_ID = ( SELECT departments.DEPARTMENT_ID FROM departments WHERE departments.DEPARTMENT_TEXT = '".$dep."') ";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $deps = array();
        while($raw = mysqli_fetch_assoc($r)){
            array_push($deps, $raw);
        }
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= $deps ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
//	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "يرجي اختيار القسم";
}

ob_end_clean();
echo json_encode($response);
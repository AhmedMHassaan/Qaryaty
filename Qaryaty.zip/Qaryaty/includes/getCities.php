<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$govName = $_GET['govName'];

if (isset($govName) && ! empty($govName)) {
  
  
    $query = " SELECT * FROM cities WHERE cities.GOV_ID = (SELECT governorates.GOV_ID FROM governorates WHERE governorates.NAME =  '".$govName."' ) ";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $cities = array();
        while($raw = mysqli_fetch_assoc($r)){
            array_push($cities, $raw);
        }
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= $cities;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "يرجي اختيار اسم المحافظة";
}

ob_end_clean();
echo json_encode($response);
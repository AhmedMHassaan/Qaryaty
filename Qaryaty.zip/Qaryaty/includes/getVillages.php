<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$city = $_GET['city'];

if (isset($city)) {
    
  
    $query = " SELECT * FROM villages WHERE villages.CITY_ID = (SELECT cities.CITY_ID FROM cities WHERE cities.NAME = '".$city."' )";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $villages = array();
        while($raw = mysqli_fetch_assoc($r)){
            array_push($villages, $raw);
        }
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= $villages;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "يرجي اختيار اسم االمركز";
}

ob_end_clean();
echo json_encode($response);
<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => -1  );
ob_start();

$data = json_decode(file_get_contents('php://input'), true);


$docUsername = $data['D_PHONE'];
$clinicPhone = $data['CLINIC_PHONE'];
$clinicAddress = $data['ADDRESS'];
$price = $data['BOOKING_PRICE'];
$service = $data['SERVICE'];
// $ = $data[''];

if (
        isset($docUsername)  && ! empty ($docUsername)  &&
        isset($clinicPhone) && ! empty($clinicPhone) &&
        isset($price) && ! empty($price) &&
        isset($service) && ! empty($service)   ) {
    
    
    
    
    /*$response['message'] = $data;
    echo json_encode($response);
    return ;*/
    
    /* $address = "    SELECT address.ADDRESS_ID FROM address WHERE ";
    
    if(isset($gov)){
        $address.= "address.GOV_ID = (SELECT governorates.GOV_ID FROM governorates where  governorates.gov_name = '".$gov."' )" ;
        
        if (isset($city)){
            $address .= "  AND address.CITY_ID = (SELECT cities.CITY_ID FROM cities WHERE cities.CITY = '".$city."' )"; 
        }else{
            $address .= " AND address.CITY_ID IS NULL ";
        }
        
        if (isset($village)){
            $address .= " AND address.VILLAGE_ID = (SELECT villages.VILLAGE_ID FROM villages WHERE villages.VILLAGE = '".$village."') ";
        }else{
            $address .=" AND address.VILLAGE_ID IS NULL ";
        }
        
        // $address .= " ) ";  // beacause ( is oppent in the first of the select statement ;
        
        
    }else{
        $address = "";
    }*/
    
    
    
    

  
    $query = " INSERT INTO `clinics` (`CLINICS_ID`, `PHONE`, `BOOKING_PRICE`, `ADDRESS`, `SERVICE_ID`, `USER_ID`, `created_at`, `updated_at`)
    
    VALUES ( 
                NULL,
                '".$clinicPhone."',
                '".$price."',
                '".$clinicAddress."',
                ( SELECT services.SERVICE_ID FROM `services` WHERE services.SERVICE_TEXT = '".$service."'  ),
                ( SELECT users.USER_ID FROM users WHERE users.PHONE = '".$docUsername."' ) ,
                NULL,
                NULL
                
            )  ";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $raw = mysqli_fetch_assoc(mysqli_query($con, "SELECT MAX(clinics.CLINICS_ID) as N FROM clinics "));
        $id = $raw['N'];
        
        if($id != null && $id > 0){
              
              $response['code']=1;
              $response['message']= "";
              $response['response']= $id ;
              
        }else{
            $response['code']=0;
              $response['message']= "حدث خطأ في معرف العيادة ";
              $response['response']= -1 ;
        }
      
    //   $response['code']=1;
    //   $response['message']= "";
    //   $data['CLINIC_ID'] = $id ;
    //   $response['response']= $data ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
          $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con);
         $error =  mysqli_error($con); 
        //  if(strpos($error, '' ) !== false){
             
        //  }
        
        if(strpos($error, 'BOOKING_PRICE' ) !== false){
             $response['message'] = "خطأ في السعر";
         }elseif(strpos($error, 'USER_ID' ) !== false){
               $response['message'] = "خطأ في رقم الهاتف او اسم المستخدم ";
         }elseif(strpos($error, 'SERVICE_ID' ) !== false){
               $response['message'] = "خطأ في  الخدمة";
         }
         
         
	


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
    

$msg =  " D_Phone = ". $data['D_PHONE']. "\n".
        " Clinic Phone = " . $data['CLINIC_PHONE'] . " \n".
        " Price = ". $data['BOOKING_PRICE'] ."\n".
        " Address = " . $data['ADDRESS'] . "\n".
        " Service = ". $data['SERVICE'] . "\n\n\n\n"
        . "Data \n".json_encode($data);
        
   $response['code'] =0;
  $response['message'] = "Complete All Required Data \n";
  $response['message'] = $msg ;

}

ob_end_clean();
echo json_encode($response);
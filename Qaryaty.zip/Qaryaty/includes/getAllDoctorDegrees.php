<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

// $ = $_POST[''];

// if (isset($)) {
  
    $query = "SELECT * FROM doc_degrees  ORDER BY doc_degrees.DEGREES_ID ASC";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $result = array();
        
        while ($raw = mysqli_fetch_assoc($r)){
            
            array_push($result, $raw);
        }
      $response['code']=1;
      $response['message']= "";
      $response['response']= $result;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


// }else{
//   $response['code'] =0;
//   $response['message'] = "Complete All Required Data ";
// }

ob_end_clean();
echo json_encode($response);
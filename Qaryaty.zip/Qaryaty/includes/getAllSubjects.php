<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();



    $query = "SELECT * FROM  subjects ";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $subs = array();
        while($raw = mysqli_fetch_assoc($r)){
            array_push($subs, $raw);
        }
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= $subs;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
        $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }




ob_end_clean();
echo json_encode($response);
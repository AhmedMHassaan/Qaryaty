<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$level = $_GET['level'];

if (isset($level) && ! empty($level)) {
  
    $query = "SELECT
                    groups.*, levels.LEVEL_TEXT
             FROM `groups` 
                inner join levels
                    on groups.LEVEL_ID = levels.LEVEL_ID
                    
            WHERE groups.LEVEL_ID = (SELECT levels.LEVEL_ID FROM levels WHERE levels.LEVEL_TEXT = '".$level."' )";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $stages = array();
        while($raw = mysqli_fetch_assoc($r)){
            array_push($stages, $raw);
        }
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= $stages;  
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
//	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "يرجي اختيار الصف ";
}

ob_end_clean();
echo json_encode($response);
<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$empId = $_GET['id'];
// $serId = $_GET['serviceId'];

if (isset($empId)  ) {
  
    $query = "SELECT 
users.NAME   , ratings.*

FROM`ratings`

INNER JOIN users 
	ON users.USER_ID = ratings.USER_ID 

where users.PHONE = '".$empId."'  ";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $rates = array();
        while($raw = mysqli_fetch_assoc($r)){
            array_push($rates, $raw);
        }
      $response['code']=1;
      $response['message']= "";
      $response['response']= $rates ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
// 	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "Complete All Required Data ";
}

ob_end_clean();
echo json_encode($response);
<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => false  );
ob_start();

$data = json_decode(file_get_contents('php://input'), true);

					

$email  = $data['USERNAME'];
$statues   = $data['STATUES'];
$time   = $data['req_dateTime_sent'];
$clinicId   = $data['CLINICS_ID'];

if (isset($email)&& isset($statues) && $clinicId ) {
  
  

  
/*  $query  = "SELECT * FROM `requests`
            WHERE requests.PATIENT_USERNAME = '".$email."'
            and requests.CLINIC_ID =  '".$clinicId."' 
            ";
            
            
         $r = mysqli_query($con , $query);
         
         if($r){
             
             $raw = mysqli_fetch_assoc($r);
             if($raw){
                
                $response['code']=0;
                $response['message']="لقد قمت بعمل حجزز وهوو مازال قيد الإننتظار \n  يرجي الإنتظار ";
                ob_end_clean();
                echo json_encode($response);
                return;
             }
         }*/
 
    $query = "INSERT INTO `requests` (`REQUEST_ID`, `USERNAME`, `req_num`, `STATUES`, `req_dateTime_sent`, `REQUEST_TIMESTAMP`, `req_dateTime_approved`, `REJECTING_REASON`, `CLINICS_ID`, `created_at`, `updated_at`)
    
    VALUES (NULL,
    '".$email."',
    '0',
    '".$statues."',
    '".$time."',
    current_timestamp(),
    NULL,
    NULL,
    '".$clinicId."',
   NULL,
   NULL
   ) ";
    
   
    
   
     $r = mysqli_query($con , $query);
     
    if ($r) {
        
      $response['code']=1;
      $response['message']= "تمت إضافة الحجز بنجاح\n انتظر حتي يتم قبول طلبك من المدير";
      $response['response']= true;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "Complete All Required Data ";
}

ob_end_clean();
echo json_encode($response);
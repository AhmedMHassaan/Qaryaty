<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => false  );
ob_start();

$data = json_decode(file_get_contents('php://input'), true);

$clinicId  = $data['CLINICS_ID'];
$cPhone  = $data['PHONE'];
$price  = $data['BOOKING_PRICE'];
$address  = $data['ADDRESS'];
$doctorId  = $data['USER_ID'];
$exYears  = ($data['doctor'])['EXPERIENCE_YEARS'];
$degree  = ($data['doctor'])['DEGREE_TEXT'];
// $  = ($data['doctor'])[''];
// $  = ($data['doctor'])[''];
// $  = ($data['doctor'])[''];
// $ = $data[''];

if ( isset($clinicId)  && ! empty ($clinicId)  ) {
    
    
    
    
    /*$response['message'] = $data;
    echo json_encode($response);
    return ;*/
    
    
    

  
    $query = " UPDATE clinics 

SET
clinics.PHONE = '".$cPhone."' , 
clinics.BOOKING_PRICE = '".$price."' , 
clinics.ADDRESS = '".$address."' 

WHERE clinics.CLINICS_ID = '".$clinicId."' ";
    
    $r = mysqli_query($con , $query);
    
    if(!r){
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
          $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con);
         $error =  mysqli_error($con); 
        //  if(strpos($error, '' ) !== false){
             
        //  }
        
        if(strpos($error, 'BOOKING_PRICE' ) !== false){
             $response['message'] = "خطأ في السعر";
         }
         
         ob_end_clean();
        echo json_encode($response);
        return;    
    }
    


    
    $query = "UPDATE doctors
                SET
                doctors.EXPERIENCE_YEARS = '".$exYears."' ,
                doctors.DEGREES_ID = (SELECT doc_degrees.DEGREES_ID FROM doc_degrees WHERE doc_degrees.TEXT = '".$degree."'  )
                
                WHERE doctors.DOCTOR_ID = '".$doctorId."'
" ;
     $r = mysqli_query($con , $query);
     
     if(!r){
         
           $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
          $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con);
         return ;
     }
    
         $response['code']=1;
         $response['message']= "تم التعديل بنجاح";
         $response['response']= true ;
         
   

}else{
    

$msg =  " D_Phone = ". $data['D_PHONE']. "\n".
        " Clinic Phone = " . $data['CLINIC_PHONE'] . " \n".
        " Price = ". $data['BOOKING_PRICE'] ."\n".
        " Address = " . $data['ADDRESS'] . "\n".
        " Service = ". $data['SERVICE'] . "\n\n\n\n"
        . "Data \n".json_encode($data);
        
   $response['code'] =0;
  $response['message'] = "لم يتم إرسال ال ID  الخاص بالعيادة ";
//   $response['message'] = $msg ;

}

ob_end_clean();
echo json_encode($response);
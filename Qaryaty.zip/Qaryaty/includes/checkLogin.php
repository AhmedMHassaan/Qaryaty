<?php 
require("connection.php");


$response = array('code' => 0, 'message' =>'' ,'response' => null  );

ob_start();
$user = $_POST['phone'];
$pass = $_POST['password'];

// $user = $_GET['phone'];
// $pass = $_GET['password'];

if(isset($user) && isset($pass)){


    $pass = md5($pass);
    
    $sql = " SELECT
    
     users.* , addresses.*, governorates.NAME as gov_name , cities.NAME as CITY , villages.NAME as VILLAGE
    FROM  users
    
    INNER JOIN addresses
        ON addresses.ADDRESS_ID = users.ADDRESS_ID
    
    INNER JOIN governorates
        ON addresses. GOV_ID   = governorates.GOV_ID
        
    LEFT JOIN cities
        ON addresses.CITY_ID    = cities.CITY_ID
        
     LEFT JOIN villages
        ON addresses.VILLAGE_ID    = villages.VILLAGE_ID
    
        
    where 
        users.PHONE= '".$user."' 
        and users.password ='".$pass."'  ";
        

    $s = mysqli_query($con, $sql);
    
    
    if ($s) {
      $raw =  mysqli_fetch_assoc($s);
      if ($raw) {
        
         $response['code'] = 1;
         $response['message'] = 'تم تسجيل الدخول بنجاح';
          $raw['IMAGE'] =base64_encode($raw['IMAGE']);
         $response['response'] = $raw;
         
        }else{
        
            $response['code'] = 0;
           $response['message'] = 'خطأ في اسم المستخدم أو كلمة المرور';
        
        }
    
    }else{
      
       $response['code'] = 0;
       $response['message'] = "خطأ من  السيرفر يرجي إخبارنا ";
       $response['message'] = "خطأ من  السيرفر يرجي إخبارنا ".mysqli_error($con);
     }
    

}else{
  $response['code']=0;
  $response['message'] = "Complete All Data";
}

 ob_end_clean();
echo json_encode($response);





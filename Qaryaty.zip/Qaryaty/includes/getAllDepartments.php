<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();


    
    
    $query = "SELECT * FROM `departments`";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $ar = array();
        while($raw = mysqli_fetch_assoc($r) ){

                array_push($ar, $raw);
        
            
        }
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= $ar ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
//  	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


ob_end_clean();
echo json_encode($response);
<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$requestId = $_POST['requestId'];
$reason = $_POST['reason'];

if (isset($requestId) && $requestId >  0) {
  
  
//       $response['message']= "id = ".$requestId ." and time is :: ". $timestamp;
//       $response['response']= true ; 
      
      
// ob_end_clean();
// echo json_encode($response);

// return ;

    $query = "UPDATE requests
    SET requests.STATUES = 'REJECTED'
    , requests.REJECTTING_REASON = '".$reason."'
    
        WHERE requests.REQUEST_ID = '".$requestId."'  ";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= true ; 
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "Complete All Required Data ";
}

ob_end_clean();
echo json_encode($response);
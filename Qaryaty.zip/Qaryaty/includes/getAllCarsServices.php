<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$gov = $_GET['gov'];
$city = $_GET['city'];
$village = $_GET['village'];
// $service = $_GET['service'];

// if (isset($service)) {
  
$phone = $_GET['phone'];
$myService = (isset($phone) && ! empty($phone) ) ;



if( ( isset($gov) && ! empty($gov) ) ||$myService ){  

  $address = " users.ADDRESS_ID = (
  SELECT addresses.ADDRESS_ID  from addresses WHERE addresses.GOV_ID = (  SELECT governorates.GOV_ID  from governorates where governorates.NAME = '".$gov."'  )
	";
  
  if(isset($city) && ! empty($city)){
      
     $address .= " AND addresses.CITY_ID = (SELECT cities.CITY_ID FROM cities WHERE cities.NAME = '".$city."' )";
  }else{
      
       $address .= " AND addresses.CITY_ID IS NULL ";
  }
  
  
  if(isset($village) && ! empty($village)){
      $address .= "  AND  addresses.VILLAGE_ID = ( SELECT villages.VILLAGE_ID FROM villages WHERE villages.NAME = '".$village."' ) ";
     
  }else{
       $address .= "AND addresses.VILLAGE_ID IS NULL";
  }
  
  $address .= " ) ";
  
}else{
    $address = "";
}
    
    if($myService){
            $query = "
            SELECT cars.*, addresses.ADDRESS_ID, governorates.NAME as gov_name , cities.NAME as CITY , villages.NAME as VILLAGE ,services.SERVICE_TEXT,  users.*, IFNULL( COUNT(ratings.USER_ID) ,0 ) as `COUNT` , IFNULL((SUM(ratings.RATE_VALUE)/ COUNT(*) ) ,0) as `RATE_VALUE` 
        
                FROM cars 
                
                INNER JOIN users 
                	ON cars.USER_ID = users.USER_ID 
                	
                INNER JOIN addresses
                	ON users.ADDRESS_ID = addresses.ADDRESS_ID
                
                INNER JOIN governorates 
                	ON governorates.GOV_ID = addresses.GOV_ID 
                
                LEFT JOIN cities 
                    ON cities.CITY_ID = addresses.CITY_ID 
                
                LEFT JOIN villages
                	ON villages.VILLAGE_ID = addresses.VILLAGE_ID
                	
                INNER JOIN services
                	ON cars.SERVICE_ID = services.SERVICE_ID
                
                LEFT OUTER JOIN ratings 
                	ON ratings.USER_ID = cars.USER_ID
                    
                    WHERE users.USER_ID = (SELECT users.USER_ID FROM users WHERE users.PHONE = '".$phone."' )
                    
                    GROUP BY cars.CAR_ID
            ";
    
    }
    else{
        $query = "
        SELECT cars.*, addresses.ADDRESS_ID, governorates.NAME as gov_name , cities.NAME as CITY , villages.NAME as VILLAGE , services.SERVICE_TEXT,  users.*, IFNULL( COUNT(ratings.USER_ID) ,0 ) as `COUNT` , IFNULL((SUM(ratings.RATE_VALUE)/ COUNT(*) ) ,0) as `RATE_VALUE` 
    
            FROM cars 
            
            INNER JOIN users 
            	ON cars.USER_ID = users.USER_ID 
            	
            INNER JOIN addresses
            	ON users.ADDRESS_ID = addresses.ADDRESS_ID
            
            INNER JOIN governorates 
            	ON governorates.GOV_ID = addresses.GOV_ID 
            
            INNER JOIN cities 
                ON cities.CITY_ID = addresses.CITY_ID 
            
            INNER JOIN villages
            	ON villages.VILLAGE_ID = addresses.VILLAGE_ID 
            
            INNER JOIN services
                	ON cars.SERVICE_ID = services.SERVICE_ID
            
            LEFT OUTER JOIN ratings 
            	ON ratings.USER_ID = cars.USER_ID
                
        
    ";
    
    
    if (strlen($address) != 0){
        // $query .=" AND " . $address ;
        $query .=" WHERE " . $address ;
    }
    $query .= " GROUP BY cars.CAR_ID ";
}

// $response['message'] = $address;
// ob_end_clean();
// echo json_encode($response);
// return ;


    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $res = array();
        $cars = array();
        $user = array();
        while($raw = mysqli_fetch_assoc($r) ){
            if($raw['CAR_ID'] != null){

                $raw['IMAGE'] = base64_encode($raw['IMAGE']);
                
                $user['ADDRESS_ID'] = $raw['ADDRESS_ID'] ;
                $user['ROLE'] = $raw['ROLE'] ;
                $user['PASSWORD'] = $raw['PASSWORD'] ;
                $user['PHONE'] = $raw['PHONE'] ;
                $user['IMAGE'] = $raw['IMAGE'] ;
                $user['NAME'] = $raw['NAME'] ;
                $user['gov_name'] = $raw['gov_name'] ;
                $user['CITY'] = $raw['CITY'] ;
                $user['VILLAGE'] = $raw['VILLAGE'] ;
                
                $cars['CAR_ID'] = $raw['CAR_ID'];
                $cars['DETAILS'] = $raw['DETAILS'];
                $cars['SERVICE_PHONE'] = $raw['SERVICE_PHONE'];
                $cars['USER_ID'] = $raw['USER_ID'];
                $cars['SERVICE_ID'] = $raw['SERVICE_ID'];
                $cars['COUNT'] = $raw['COUNT'];
                $cars['RATE_VALUE'] = $raw['RATE_VALUE'];
                $cars['SERVICE_TEXT'] = $raw['SERVICE_TEXT'];
                
                
                
                
                $cars['user'] = $user ;
                
                array_push($res, $cars);
            }
            
        }
        

      $response['code']=1;
      $response['message']= "";
      $response['response']= $res ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
 	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


// }else{
//   $response['code'] =0;
//   $response['message'] = "Complete All Required Data ";
// }

ob_end_clean();
echo json_encode($response);
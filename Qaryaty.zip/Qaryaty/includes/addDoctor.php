<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => false  );
ob_start();
$data = json_decode(file_get_contents('php://input'), true);

$username = ($data['info'])['PHONE'];
$spec = $data['TEXT'];
$deg = $data['DEGREE_TEXT'];
$ex = $data['EXPERIENCE_YEARS'];
// $ = $data[''];
// $ = $data[''];




// $ = $_POST[''];

if (isset($username) && isset($spec) &&   isset($deg) ) {
  
  
//   $response['message'] = json_encode($data) ;
// echo json_encode($response);
// return;




    $query = "INSERT INTO `doctors` (`DOCTOR_ID`, `EXPERIENCE_YEARS`, `SPECIALT_ID`, `DEGREES_ID`, `created_at`, `updated_at`) 
    VALUES 

(
    (SELECT users.USER_ID FROM users WHERE users.PHONE = '".$username."'),
    '".$ex."',
    ( SELECT doc_specialties.SPECIALT_ID  FROM `doc_specialties` WHERE doc_specialties.TEXT = '".$spec."') ,
 (SELECT doc_degrees.DEGREES_ID FROM doc_degrees WHERE doc_degrees.TEXT =  '".$deg."'),
 
 NULL, NULL
);


";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
      $response['code']=1;
      $response['message']= "تمت الإضافة بنجاح";
      $response['response']= true ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
    // $username = $data['PHONE'];
// $spec = $data['PHONE'];
// $deg = $data['DEGREE_TEXT'];
// $ex = $data['EXPERIENCE_YEARS'];

$msg = json_encode($data);



   $response['code'] =0;
   $response['message'] = "Complete All Required Data ";
//   $response['message'] = "Complete All Required Data 
//   \n Phone = ".($data['info'])['PHONE'].
//   "\n Spec = ".$data['TEXT'] . 
//   "\n Deg  = ".$data['DEGREE_TEXT'] .
//   "\n Years = ".$data['EXPERIENCE_YEARS'];
    // $response['message'] = $msg;
  
}

ob_end_clean();
echo json_encode($response);
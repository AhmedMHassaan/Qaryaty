<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();



    $query = "SELECT * FROM ads_types";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $types = array();
        while($raw = mysqli_fetch_assoc($r)){
            array_push($types, $raw);
        }
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= $types;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }




ob_end_clean();
echo json_encode($response);
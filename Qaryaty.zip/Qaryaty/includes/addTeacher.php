<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => false  );
ob_start();

$data = json_decode(file_get_contents('php://input'), true);

$id = $data['TECHER_ID'];
$levelId = $data['LEVEL_ID'];
$details = $data['PORTFOLIO'];
$owner = $data['PHONE'];
$tName = $data['TEACHER_NAME'];
// $gov = $data['gov_name'];
// $city = $data['CITY'];
// $village = $data['VILLAGE'];
$service = $data['SERVICE_TEXT'];

$subId = $data['SUBJECT_ID'];


// $ = $data[''];

if (isset($levelId) && isset($owner) ) {
    
    
    
    
    /*$response['message'] = $data;
    echo json_encode($response);
    return ;*/
    
    /* $address = "    SELECT address.ADDRESS_ID FROM address WHERE ";
    
    if(isset($gov)){
        $address.= "address.GOV_ID = (SELECT governorates.GOV_ID FROM governorates where  governorates.gov_name = '".$gov."' )" ;
        
        if (isset($city)){
            $address .= "  AND address.CITY_ID = (SELECT cities.CITY_ID FROM cities WHERE cities.CITY = '".$city."' )"; 
        }else{
            $address .= " AND address.CITY_ID IS NULL ";
        }
        
        if (isset($village)){
            $address .= " AND address.VILLAGE_ID = (SELECT villages.VILLAGE_ID FROM villages WHERE villages.VILLAGE = '".$village."') ";
        }else{
            $address .=" AND address.VILLAGE_ID IS NULL ";
        }
        
        // $address .= " ) ";  // beacause ( is oppent in the first of the select statement ;
        
        
    }else{
        $address = "";
    }
    
    */
    
    
    if(isset($id) && !empty($id)){
        

        $query = "UPDATE teachers
                    SET 
                    teachers.TEACHER_NAME = '".$tName."' , 
                    teachers.PORTFOLIO = '".$details."' 
                    
                    WHERE teachers.TECHER_ID = '".$id."' ";
        
    }else{

  
    $query = " INSERT INTO `teachers` (`TECHER_ID`, `TEACHER_NAME`, `PORTFOLIO`, `LEVEL_ID`, `SUBJECT_ID`, `SERVICE_ID`, `created_at`, `updated_at`) 
    
    VALUES  ( 
                (SELECT users.USER_ID FROM users WHERE users.PHONE = '".$owner."'),
                '".$tName."' ,
                '".$details."',
                '".$levelId."',
                '".$subId."',
                (SELECT services.SERVICE_ID FROM services WHERE services.SERVICE_TEXT = '".$service."'  ) ,
                NULL,
                NULL
                
            ) ";
    
    }
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
      
        
      $response['code']=1;
      if(isset($id) && !empty($id))
        $response['message']= "تم التعديل بنجاح";
      else
        $response['message']= "تمت الإضافة بنجاح";
      
      $response['response']= true ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
         
         $error = mysqli_error($con);
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con);
         if (strpos($error, 'ADDRESS_ID') !== false ) {
             $response['message'] = "خطأ في العنوان";
         }
         elseif (strpos($error, 'SERVICE_ID') !== false ) {
             $response['message'] = "خطأ في الخدمة";
         }
         elseif (strpos($error, 'LEVEL_ID') !== false ) {
             $response['message'] = "خطأ في المستوي";
         }
         elseif (strpos($error, 'SUBJECT_ID') !== false ) {
             $response['message'] = "خطأ في االمادة";
         }
         elseif (strpos($error, 'PHONE') !== false ) {
             $response['message'] = "خطأ في  رقم هاتف المدرس";
         }
         
	 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "Complete All Required Data ";
}

ob_end_clean();
echo json_encode($response);
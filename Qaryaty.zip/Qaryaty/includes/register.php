<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$data = json_decode(file_get_contents('php://input'), true);



$id = $data['USER_ID'];
$phone = $data['PHONE'];
$dep = $data['DEPARTMENT'];
$pass = $data['password'];
$name = $data['NAME'];
$role = $data['ROLE'];
$img = $data['IMAGE'];
$gov = $data['gov_name'];
$city = $data['CITY'];
$village = $data['VILLAGE'];





if (
    isset($phone) &&! empty($phone) &&
    isset($pass) && ! empty($pass)  &&
    isset($name) &&! empty($name) &&
    isset($role) && ! empty($role) &&
    isset($gov) && ! empty($gov) 
    ) {
  
//   $pass = MD5($pass);
  
//   $response['message']=  $gov.$city.$village."" ;
//  ob_end_clean();
//  echo json_encode($response);
//   return ;
  
  



  $addressQuery = "
  SELECT addresses.ADDRESS_ID  from addresses WHERE addresses.GOV_ID = (  SELECT governorates.GOV_ID  from governorates where governorates.NAME = '".$gov."'  )
	";
  
  if(isset($city) && ! empty($city)){
      
     $addressQuery .= " AND addresses.CITY_ID = (SELECT cities.CITY_ID FROM cities WHERE cities.NAME = '".$city."' )";
  }else{
      
       $addressQuery .= " AND addresses.CITY_ID IS NULL ";
  }
  
  
  if(isset($village) && ! empty($village)){
      $addressQuery .= "  AND  addresses.VILLAGE_ID = ( SELECT villages.VILLAGE_ID FROM villages WHERE villages.NAME = '".$village."' ) ";
     
  }else{
       $addressQuery .= "AND addresses.VILLAGE_ID IS NULL";
  }
  
  
  
 

  if(isset($id) && $id >0){
      
      $query = "UPDATE `users` SET    
                        `NAME`=  '".$name."',
                        `PHONE`= '".$phone."' ,
                        `IMAGE` = '".$img."'
                        WHERE users.USER_ID = '".$id."' ";
                        
                      
                      
                      
                        

  }else{


  
  
   $query= "  INSERT INTO `users` (`USER_ID`, `NAME`, `ROLE`, `password`, `PHONE`,`DEPARTMENT`, `IMAGE`, `ADDRESS_ID`, `remember_token`, `created_at`, `updated_at`) 

                VALUES(
                        NULL,
                        '".$name."',
                        '".$role."',
                        md5('".$pass."'),
                        '".$phone."' ,
                        '".$dep."',
                        '".$img."',
                        (".$addressQuery."),
                        NULL,
                        NULL,
                        NULL
                         
                        ) ";
                        
  
                        
  }       
   
   
   
     $r = mysqli_query($con , $query);
                    
  
    if ($r) {

        
        $user = array();
    
    if(isset($id) && $id >0)
          $user['USER_ID'] = $id;

        $user['PHONE'] = $phone;
        $user['NAME'] =$name ;
        $user['ROLE'] = $role;
        $user['IMAGE'] = $img;
        $user['gov_name'] = $gov ;
        $user['CITY'] = $city ;
        $user['VILLAGE'] = $village ;
        $user['password'] = $pass ;
        
        
        
        
      $response['code']=1;
       
  if(isset($id) && $id >0){
      
         $response['message']= "تم تحديث بياناتك ";
        
  }else{
       $response['message']= "تم التسجيل بنجاح\nسيتم توجيهك لصفحة الدخول الآن";
  }
     
      $response['response']= $user;
        
    
    }else{
        // error(mysqli_error($con));
        
          $response['code'] =0;
         
         $error = mysqli_error($con) ;
         if(strpos($error, 'PHONE') !== false ){
             $response['message'] = "رقم التليفون مستخدم من قبل شخص آخر";
         }else if(strpos($error, 'ADDRESS_ID') !== false ){
             $response['message'] = "خطأ في العنوان ";
         }
         else{
        
                 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
            	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".$error ; 
            }
            
    }


}else{



// $msg = " PHONE" .  $data['PHONE'] . " \n".
//       "PASSWORD" .  $data['password'] . " \n".
//       "NAME" .  $data['NAME'] . " \n".
//       "ROLE" .  $data['ROLE'] . " \n".
//       "gov_name" .  $data['gov_name'] . " \n".
//       "USER_ID" .  $data['USER_ID'] . " \n";

   $response['code'] =0;
  $response['message'] = "Complete All Required Data\n\n\n ";
}

ob_end_clean();
echo json_encode($response);




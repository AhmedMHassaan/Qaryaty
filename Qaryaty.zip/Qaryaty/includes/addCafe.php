<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => false  );
ob_start();

$data = json_decode(file_get_contents('php://input'), true);

$id = $data['REST_ID'];
$name = $data['REST_NAME'];
$details = $data['REST_DETAILS'];
$owner = $data['PHONE'];
$service = $data['SERVICE_TEXT'];

// $ = $data[''];


// $ = $data[''];

if (isset($name) && ! empty($name)) {
    
    
    
    
    /*$response['message'] = $data;
    echo json_encode($response);
    return ;*/
    
    
    
    
    if(! empty($id) && isset($id)){
        
        $query = "UPDATE restaurants
                    SET
                    restaurants.REST_NAME = '".$name."' ,
                    restaurants.REST_DETAILS = '".$details."' 
                    
                    WHERE restaurants.REST_ID = '".$id."' ";
    }else{
    
        $query = "  INSERT INTO `restaurants` (`REST_ID`, `REST_NAME`, `REST_DETAILS`, `SERVICE_ID`, `USER_ID`, `created_at`, `updated_at`)
        
        VALUES  (NULL, '".$name."', '".$details."', (SELECT services.SERVICE_ID FROM services  WHERE services.SERVICE_TEXT = ".$service."'), ( SELECT users.USER_ID FROM users  WHERE users.PHONE =  '".$owner."')  , current_timestamp(), NULL   ) ";
        
    }
    $r = mysqli_query($con , $query);
    if ($r) {
        
      
       
      $response['code']=1;
       if(! empty($id) && isset($id ) )
            $response['message']= "تم التعديل بنجاح";
        else
      $response['message']= "تمت الإضافة بنجاح";
      $response['response']= true ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
         
         $error = mysqli_error($con);
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con);
         if (strpos($error, 'ADDRESS_ID') !== false ) {
             $response['message'] = "خطأ في العنوان";
         }
         elseif (strpos($error, 'SERVICE_ID') !== false ) {
             $response['message'] = "خطأ في الخدمة";
         }
         elseif (strpos($error, 'OWNER') !== false ) {
             $response['message'] = "خطأ في  رقم هاتف المالك";
         }
         
	 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "Complete All Required Data ";
}

ob_end_clean();
echo json_encode($response);
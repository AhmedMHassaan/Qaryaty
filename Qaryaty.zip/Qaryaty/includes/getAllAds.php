<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

// $ = $_POST[''];

// if (isset($)) {
  $phone = $_GET['phone'];
  if(isset($phone) && ! empty($phone)){
      $query = "SELECT 
    	ads.*,
    	ads_categories.*,
    	ads_types.*,
        users.*,
        addresses.ADDRESS_ID,
        governorates.NAME as gov_name,
        villages.NAME as VILLAGE,
        cities.NAME as CITY
    
    FROM 
    	`ads`
        
        INNER JOIN ads_categories
        	ON ads_categories.CAT_ID = ads.CATEGORY_ID
         
         INNER JOIN ads_types
         	on ads_types.TYPE_ID = ads.AD_TYPE_ID
            
           INNER JOIN users
         	on users.USER_ID = ads.USER_ID
            
            INNER JOIN addresses
            	on addresses.ADDRESS_ID = users.ADDRESS_ID
            
            INNER JOIN governorates
            	on governorates.GOV_ID = addresses.GOV_ID
            
            LEFT JOIN cities
            	on cities.CITY_ID = addresses.CITY_ID
            
            LEFT JOIN villages
            	on villages.VILLAGE_ID = addresses.VILLAGE_ID
            
            
            WHERE users.USER_ID = (SELECT users.USER_ID from users where users.PHONE = '".$phone."' )";
  }else{
      
  
    $query = "SELECT 
    	ads.*,
    	ads_categories.*,
    	ads_types.*,
        users.*,
        addresses.ADDRESS_ID,
        governorates.NAME as gov_name,
        villages.NAME as VILLAGE,
        cities.NAME as CITY
    
    FROM 
    	`ads`
        
        INNER JOIN ads_categories
        	ON ads_categories.CAT_ID = ads.CATEGORY_ID
         
         INNER JOIN ads_types
         	on ads_types.TYPE_ID = ads.AD_TYPE_ID
            
           INNER JOIN users
         	on users.USER_ID = ads.USER_ID
            
            INNER JOIN addresses
            	on addresses.ADDRESS_ID = users.ADDRESS_ID
            
            INNER JOIN governorates
            	on governorates.GOV_ID = addresses.GOV_ID
            
            INNER JOIN cities
            	on cities.CITY_ID = addresses.CITY_ID
            
            INNER JOIN villages
            	on villages.VILLAGE_ID = addresses.VILLAGE_ID
            
            
           ";
       }
    
    $r = mysqli_query($con , $query);
    if ($r) {
        $ads = array();
        $ad = array();
        $user = array();
        
        while($raw = mysqli_fetch_assoc($r) ){
            if($raw['ADS_ID'] != null){
                
                // user info 
                    $user['USER_ID'] = $raw['USER_ID'];
                    $user['NAME'] = $raw['NAME'];
                    $user['ROLE'] = $raw['ROLE'];
                    $user['password'] = $raw['password'];
                    $user['PHONE'] = $raw['PHONE'];
                    $user['IMAGE'] = base64_encode( $raw['IMAGE']) ;
                    $user['gov_name'] = $raw['gov_name'];
                    $user['VILLAGE'] = $raw['VILLAGE'];
                     $user['CITY'] = $raw['CITY'];
                    // $user[''] = $raw[''];
                    //  $user[''] = $raw[''];
                    // $user[''] = $raw[''];
                
                // ads info
                    $ad['ADS_ID'] = $raw['ADS_ID'];
                    $ad['TITLE'] = $raw['TITLE'];
                    $ad['STATUS'] = $raw['STATUS'];
                    $ad['USER_ID'] = $raw['USER_ID'];
                    $ad['CATEGORY_ID'] = $raw['CATEGORY_ID'];
                    $ad['DETAILS'] = $raw['DETAILS'];
                    $ad['AD_TYPE_ID'] = $raw['AD_TYPE_ID'];
                    $ad['AD_TIMESTAMP'] = $raw['AD_TIMESTAMP'];
                    $ad['CAT_TEXT'] = $raw['CAT_TEXT'];
                    $ad['TYPE_TEXT'] = $raw['TYPE_TEXT'];
                    $ad['user'] = $user;
                    // $ad[''] = $raw[''];
                    // $ad[''] = $raw[''];
                    
                $sql = "SELECT * FROM `images` WHERE AD_ID = '".$raw['ADS_ID']."'  ";
                $res = mysqli_query($con, $sql);
                
                if ($res){
                    $images = array();
                    while($img = mysqli_fetch_assoc($res)){
                        $img['IMAGE'] = base64_encode($img['IMAGE']);
                        array_push($images, $img);
                    }
                    $ad['images'] = $images ;
                }
                
                array_push($ads, $ad);
            }
        }
      $response['code']=1;
      $response['message']= "";
      $response['response']= $ads ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
//	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


// }else{
//   $response['code'] =0;
//   $response['message'] = "Complete All Required Data ";
// }

ob_end_clean();
echo json_encode($response);
<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$gov = $_GET['gov'];
$city = $_GET['city'];
$village = $_GET['village'];
$service = $_GET['service'];
$phone = $_GET['phone'];

$myTrans = false ;
if(isset($phone) && !empty($phone) )
    $myTrans = true ;
    
if ( (isset($service) && !empty($service) )  ||  $myTrans ) {
  
  
  $address = "   
    addresses.ADDRESS_ID = ( SELECT addresses.ADDRESS_ID FROM addresses WHERE ";
    
    if(isset($gov)  && ! empty($gov)){
        
        $address.= "addresses.GOV_ID = (SELECT governorates.GOV_ID FROM governorates where  governorates.NAME = '".$gov."' ) " ;
        
        if (isset($city) && ! empty($city) ){
            $address .= "  AND addresses.CITY_ID = (SELECT cities.CITY_ID FROM cities WHERE cities.NAME = '".$city."' )"; 
        }else{
            $address .= " AND addresses.CITY_ID IS NULL ";
        }
        
        if (isset($village) && ! empty($village) ){
            $address .= " AND addresses.VILLAGE_ID = (SELECT villages.VILLAGE_ID FROM villages WHERE villages.NAME = '".$village."') ";
        }else{
            $address .=" AND addresses.VILLAGE_ID IS NULL ";
        }
        
        $address .= " ) ";  // beacause ( is oppent in the first of the select statement ;
        
        
    }else{
        $address = "";
    }
    
    
    if($myTrans){
        $query = "SELECT
           transports.*,
           transports.NAME as `TRANS_NAME`,
           services.*, 
           users.*,
           governorates.NAME as gov_name,
           cities.NAME as CITY,
           villages.NAME as VILLAGE,
           addresses.ADDRESS_ID, 
           IFNULL(  COUNT(ratings.USER_ID) ,0 ) as `COUNT`,
           IFNULL((SUM(ratings.RATE_VALUE)/ COUNT(ratings.USER_ID) ) ,0) as `RATE_VALUE`
        
    FROM 
    	transports 
    
    INNER JOIN users 
    	ON users.USER_ID = transports.USER_ID
    
        
    INNER JOIN addresses
    	ON addresses.ADDRESS_ID = users.ADDRESS_ID
    	
    INNER JOIN governorates
    	ON addresses.GOV_ID = governorates.GOV_ID
    	
    INNER JOIN cities 
    	ON addresses.CITY_ID = cities.CITY_ID
    	
    INNER JOIN villages 
    	ON addresses.VILLAGE_ID = villages.VILLAGE_ID
    	
    	
    INNER JOIN services 
    	ON services.SERVICE_ID = transports.SERVICE_ID
    
    LEFT JOIN ratings 
    	ON  ratings.USER_ID = transports.USER_ID
       
       WHERE users.USER_ID = (SELECT users.USER_ID FROM users WHERE users.PHONE = '".$phone."')
       
       GROUP BY transports.TRANSPORT_ID ";
    }else{
    	   
        $query = "
    SELECT
           transports.*,
           transports.NAME as `TRANS_NAME`,
           services.*, 
           users.*,
           governorates.NAME as gov_name,
           cities.NAME as CITY,
           villages.NAME as VILLAGE,
           addresses.ADDRESS_ID, 
           IFNULL(  COUNT(ratings.USER_ID) ,0 ) as `COUNT`,
           IFNULL((SUM(ratings.RATE_VALUE)/ COUNT(ratings.USER_ID) ) ,0) as `RATE_VALUE`
        
    FROM 
    	transports 
    
    INNER JOIN users 
    	ON users.USER_ID = transports.USER_ID
    
        
    INNER JOIN addresses
    	ON addresses.ADDRESS_ID = users.ADDRESS_ID
    	
    INNER JOIN governorates
    	ON addresses.GOV_ID = governorates.GOV_ID
    	
    INNER JOIN cities 
    	ON addresses.CITY_ID = cities.CITY_ID
    	
    INNER JOIN villages 
    	ON addresses.VILLAGE_ID = villages.VILLAGE_ID
    	
    	
    INNER JOIN services 
    	ON services.SERVICE_ID = transports.SERVICE_ID
    
    LEFT JOIN ratings 
    	ON  ratings.USER_ID = transports.USER_ID
        
        WHERE 
        services.SERVICE_ID = (SELECT services.SERVICE_ID FROM `services` WHERE SERVICE_TEXT = '".$service."')
    ";
    
    if (strlen($address) != 0 && ! empty($address) ){
        $query .=" AND " . $address ;
    }
$query.= " GROUP BY transports.TRANSPORT_ID ";

}
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $trans = array();
        
        while($raw = mysqli_fetch_assoc($r)){
            if($raw['TRANSPORT_ID'] != null ){
                $raw['IMAGE'] =base64_encode($raw['IMAGE']);
                array_push($trans, $raw);
            }
            
        }
      $response['code']=1;
      $response['message']= "تم العثور علي نتيجة";
      $response['response']= $trans ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
  $response['code'] =0;
  $response['message'] = "Complete All Required Data ";
  $response['message'] = "يرجي اختيار الخدمة أولا";
}

ob_end_clean();
echo json_encode($response);
<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => false  );
ob_start();


$clinicId = $_POST['id'];
$day= $_POST['day'];
$openTime= $_POST['openTime'];
$closeTime= $_POST['closeTime'];


if (isset($clinicId) && !empty($clinicId)  && isset($day) &&  !empty($day) ) {
    
    
    


    
    $query = "INSERT INTO 
            `clinic_days` 
            (`DAY_ID`, `OPEN_TIME`, `END_TIME`, `CLINICS_ID`, `WEEK_ID`, `created_at`, `updated_at`)
            
            VALUES 
            (
                NULL,
                '".$openTime."',
                '".$closeTime."',
                '".$clinicId."', 
                (SELECT weeks.WEEK_ID FROM `weeks` WHERE weeks.DAY = '".$day."'), 
                NULL,
                NULL
             ) ";
    
    $r = mysqli_query($con , $query);
    
    if ($r) {
        
       
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= true ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con);


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "Complete All Required Data ";
}

ob_end_clean();
echo json_encode($response);



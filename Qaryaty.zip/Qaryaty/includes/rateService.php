<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => false  );
ob_start();

$username = $_POST['username'];
$serviceOwner = $_POST['emp'];
// $service = $_POST['serviceId'];
$rateValue = $_POST['rate'];
$comment = $_POST['comment'];
// $ = $_POST[''];

if (isset($username)  &&  isset($serviceOwner) ) {
  
  


    $query = "INSERT INTO `ratings` (`RATE_ID`, `COMMENT`, `RATE_VALUE`, `USER_ID`, `RATER_ID`, `created_at`, `updated_at`)
    
    VALUES (
            NULL,
            '".$comment."',
            '".$rateValue."',
            (SELECT users.USER_ID FROM users WHERE users.PHONE = '".$serviceOwner."'),
            (SELECT users.USER_ID FROM users WHERE users.PHONE = '".$username."'),
            NULL,
            NULL
            )
";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
      $response['code']=1;
      $response['message']= "تم التقييم بنجاح";
      $response['response']= true ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
         $error =  mysqli_error($con); 
         
	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 

        // if(strpos($error, '') !== false){
        //     $response['message'] = "";
        // }
        
        if(strpos($error, 'SERVICE_ID') !== false){
            $response['message'] = "خطأ في الخدمة";
        }
        elseif(strpos($error, 'RATE_VALUE') !== false){
            $response['message'] = "خطأ في التقييم";
        }
        elseif(strpos($error, 'RATER_ID') !== false){
            $response['message'] = "خطأ في اسم المستخدم";
        }
        elseif(strpos($error, 'USER_ID') !== false){
            $response['message'] = "خطأ في  الموظف";
        }
        
        
        

            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "Complete All Required Data ";
}

ob_end_clean();
echo json_encode($response);
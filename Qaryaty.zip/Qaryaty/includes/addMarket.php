<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => false  );
ob_start();

$data = json_decode(file_get_contents('php://input'), true);

$id = $data['MARKET_ID'];
$name = $data['MARKET_NAME'];
$details = $data['DETAILS'];
$owner = $data['PHONE'];
// $gov = $data['gov_name'];
// $city = $data['CITY'];
// $village = $data['VILLAGE'];
$service = $data['SERVICE_TEXT'];

// $ = $data[''];


// $ = $data[''];

if (isset($name)  && ! empty($name) ) {
    
    
    
    
    /*$response['message'] = $data;
    echo json_encode($response);
    return ;*/
    
  /*   $address = "    SELECT address.ADDRESS_ID FROM address WHERE ";
    
    if(isset($gov)){
        $address.= "address.GOV_ID = (SELECT governorates.GOV_ID FROM governorates where  governorates.gov_name = '".$gov."' )" ;
        
        if (isset($city)){
            $address .= "  AND address.CITY_ID = (SELECT cities.CITY_ID FROM cities WHERE cities.CITY = '".$city."' )"; 
        }else{
            $address .= " AND address.CITY_ID IS NULL ";
        }
        
        if (isset($village)){
            $address .= " AND address.VILLAGE_ID = (SELECT villages.VILLAGE_ID FROM villages WHERE villages.VILLAGE = '".$village."') ";
        }else{
            $address .=" AND address.VILLAGE_ID IS NULL ";
        }
        
        // $address .= " ) ";  // beacause ( is oppent in the first of the select statement ;
        
        
    }else{
        $address = "";
    }
    
    */
    

if(isset($id) && ! empty($id)){
    
    
 
 
 
    $query = "UPDATE  markets
                SET
                markets.MARKET_NAME = '".$name."' , 
                markets.DETAILS = '".$details."' 
                
                WHERE markets.MARKET_ID = '".$id."' ";
}else{
  
    $query = " INSERT INTO `markets` (`MARKET_ID`, `MARKET_NAME`, `DETAILS`, `SERVICE_ID`, `USER_ID`, `created_at`, `updated_at`)
    
    VALUES  (
                NULL,
                '".$name."',
                '".$details."' ,
                (SELECT services.SERVICE_ID FROM services WHERE services.SERVICE_TEXT = '".$service."'),
                (SELECT users.USER_ID FROM users WHERE users.PHONE = '".$owner."'),
                NULL,
                NULL
                   ) ";
    
    
}
    $r = mysqli_query($con , $query);
    if ($r) {
        
      
        
      $response['code']=1;
      
      if(isset($id) && ! empty($id))
        $response['message']= "تمت التعديل بنجاح";
      else
        $response['message']= "تمت الإضافة بنجاح";
        
      $response['response']= true ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
         
         $error = mysqli_error($con);
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con);
         if (strpos($error, 'ADDRESS_ID') !== false ) {
             $response['message'] = "خطأ في العنوان";
         }
         elseif (strpos($error, 'SERVICE_ID') !== false ) {
             $response['message'] = "خطأ في الخدمة";
         }
         elseif (strpos($error, 'MARKET_OWNER') !== false ) {
             $response['message'] = "خطأ في  رقم هاتف المالك";
         }
         
                //   $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con);
	 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "Complete All Required Data " ;
}

ob_end_clean();
echo json_encode($response);
<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$clincId = $_POST['clinicId'];


if (isset($clincId)) {
  
    $query = "SELECT
	clinic_days.*, weeks.*, clinics.CLINICS_ID

FROM
	clinic_days

INNER JOIN weeks
	ON weeks.WEEK_ID = clinic_days.WEEK_ID

INNER JOIN clinics 
	ON clinic_days.CLINICS_ID = clinics.CLINICS_ID
    

WHERE clinics.CLINICS_ID =  '".$clincId."'";


    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        
        $days = array();
        
        while($raw = mysqli_fetch_assoc($r)){
            array_push($days, $raw);
        }
      $response['code']=1;
      $response['message']= "";
      $response['response']= $days ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "Complete All Required Data ";
}

ob_end_clean();
echo json_encode($response);
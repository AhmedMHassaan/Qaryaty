<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$requestId = $_POST['requestId'];
$timestamp = $_POST['timestamp'];

if (isset($requestId) && $requestId >  0 &&  isset($timestamp)) {
  
  
//       $response['message']= "id = ".$requestId ." and time is :: ". $timestamp;
//       $response['response']= true ; 
      
      
// ob_end_clean();
// echo json_encode($response);

// return ;

    $query = "UPDATE requests
    SET requests.STATUES = 'ACCEPTED'
    , requests.req_dateTime_approved = '".$timestamp."'
    
    
        WHERE requests.REQUEST_ID = '".$requestId."'  ";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= true ; 
        
    
    }else{
    
    
    
    $error = mysqli_error($con);  
    
    
    
    
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 

        if(strpos($error, 'datetime') !== false){
                     $response['message'] = "خطأ في قيمة التاريخ";
        }
        
        $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 

            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
   $response['code'] =0;
  $response['message'] = "Complete All Required Data ";
}

ob_end_clean();
echo json_encode($response);
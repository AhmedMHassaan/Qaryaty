<?php

 
  class connection
 {
 
 	
 	public function connect()
 	{
 		$con = @mysqli_connect("localhost" , "id13442516_qaryaty_" ,"Ahmed1123@1123" , "id13442516_qaryaty");
 		if ($con) {
 			// echo "Connected";
 		}else{
 			// die("غير قادر على الإتصال بالسيرفر \n يرجي التأكد من الإتصال بالإنترنت و إعادة المحاولة") ;// Not Connected !
 		

 		}
 		return $con;
 	}

 }

$connection  = new connection();
$con = $connection->connect();
 ?>
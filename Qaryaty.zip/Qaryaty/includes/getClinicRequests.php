<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$phone = $_GET['phone'];

if (isset($phone) && ! empty($phone)) {
  
    $query = "
            SELECT
            requests.*, users.NAME, s.PHONE, s.NAME as DOCTOR_NAME, clinics.CLINICS_ID
            
            FROM requests
            
            INNER JOIN users
            	ON users.PHONE = requests.USERNAME
                
            INNER  JOIN clinics
            	ON clinics.CLINICS_ID = requests.CLINICS_ID
                
            INNER JOIN users s 
            	ON s.USER_ID = clinics.USER_ID
            		where  requests.USERNAME = '".$phone."'
            	";
}else{
     $query = " SELECT
            requests.*, users.NAME, s.PHONE, s.NAME as DOCTOR_NAME, clinics.CLINICS_ID
            
            FROM requests
            
            INNER JOIN users
            	ON users.PHONE = requests.USERNAME
                
            INNER  JOIN clinics
            	ON clinics.CLINICS_ID = requests.CLINICS_ID
                
            INNER JOIN users s 
            	ON s.USER_ID = clinics.USER_ID
           	";

            
}
/*INNER JOIN users s 
            	ON s.uname = clinics.DOCTOR_USERNAME";*/
                
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $request = array();
        while($raw = mysqli_fetch_assoc($r)){
            array_push($request, $raw);
        }
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= $request ;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


// }else{
//   $response['code'] =0;
//   $response['message'] = "Complete All Required Data ";
// }

ob_end_clean();
echo json_encode($response);
<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();



    $query = "SELECT * FROM ads_categories ";
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        $cats = array();
        while($raw = mysqli_fetch_assoc($r)){
            array_push($cats, $raw);
        }
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= $cats;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }




ob_end_clean();
echo json_encode($response);
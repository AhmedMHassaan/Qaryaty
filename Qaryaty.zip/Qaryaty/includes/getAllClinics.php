<?php 

require ('connection.php');

$response = array('code' => 0, 'message' =>'' ,'response' => null  );
ob_start();

$gov = $_GET['gov'];
$city = $_GET['city'];
$village = $_GET['village'];
$specialty = $_GET['specialty'];




// $response['message'] = "Gov : ".$gov . "\n".
//                         "$city : ".$city . "\n".
//                          "$village : ".$village . "\n".
//                           "$specialty : ". $specialty. "\n";
// ob_end_clean();
// echo json_encode($response);
// return ;


if ( ! empty($specialty)) {
  
  
  
  if(isset($gov) && ! empty($gov) ){
    
      $addressQuery = "   SELECT addresses.ADDRESS_ID from addresses WHERE addresses.GOV_ID = (  SELECT governorates.GOV_ID  from governorates where governorates.NAME = '".$gov."'  )";
      
      if(isset($city) && ! empty($city)){
          
         $addressQuery .= " AND addresses.CITY_ID = (SELECT cities.CITY_ID FROM cities WHERE cities.NAME = '".$city."' )";
      }else{
          
           $addressQuery .= " AND addresses.CITY_ID IS NULL ";
      }
      
      
      if(isset($village) && ! empty($gov)){
          $addressQuery .= "  AND  addresses.VILLAGE_ID = ( SELECT villages.VILLAGE_ID FROM villages WHERE villages.NAME = '".$village."' ) ";
         
      }else{
           $addressQuery .= " AND addresses.VILLAGE_ID IS NULL";
      }
}else{
    $addressQuery = "";
}
  
  





    $query = "SELECT 
           clinics.*, doctors.*, doc_specialties.*, addresses.ADDRESS_ID, doc_degrees.DEGREES_ID,  doc_degrees.TEXT as `DEGREE_TEXT` , users.*, users.PHONE as `uname` ,services.SERVICE_TEXT ,governorates.NAME as `gov_name` , cities.NAME as `city` , villages.NAME as `VILLAGE` ,
          
           
           IFNULL(  COUNT(ratings.USER_ID) ,0 ) as `COUNT` , IFNULL((SUM(ratings.RATE_VALUE)/ COUNT(ratings.USER_ID) ) ,0) as `RATE_VALUE`
            
            
     
FROM clinics
INNER JOIN doctors
	ON doctors.DOCTOR_ID = clinics.USER_ID

INNER JOIN users
on users.USER_ID = doctors.DOCTOR_ID

 
INNER JOIN addresses
    ON users.ADDRESS_ID = addresses.ADDRESS_ID
INNER JOIN governorates
    ON governorates.GOV_ID = addresses.GOV_ID
LEFT JOIN cities
    ON cities.CITY_ID = addresses.CITY_ID
LEFT JOIN villages 
    ON villages.VILLAGE_ID = addresses.VILLAGE_ID
INNER JOIN doc_specialties
    ON doc_specialties.SPECIALT_ID = doctors.SPECIALT_ID
INNER JOIN doc_degrees 
    oN doc_degrees.DEGREES_ID = doctors.DEGREES_ID
INNER JOIN services
    ON services.SERVICE_ID = clinics.SERVICE_ID
LEFT JOIN ratings 
    ON ratings.USER_ID = doctors.DOCTOR_ID
	   
	   " ;
    	
	
	if( ! empty($addressQuery) ){
	    $query .= " WHERE users.ADDRESS_ID =  (". $addressQuery . " )  And doctors.SPECIALT_ID  = ".$specialty."  "  ;
	}else{
	    $query = $query. " WHERE doctors.SPECIALT_ID  = ".$specialty." ";
	    
	   // $query = $query. " WHERE doctors.SPECIALT_ID  = (SELECT doc_specialties.SPECIALT_ID  FROM `doc_specialties` WHERE doc_specialties.TEXT =  '".$specialty."') ";
	}
	
	$query .="  group BY doctors.DOCTOR_ID ";
	
// 	echo $query ;
// 	return ;


// $response['code'] = 0 ;
// $response['message'] = $query ;
// ob_end_clean();
// echo json_encode($response);
// return ;
  
    
    $r = mysqli_query($con , $query);
    if ($r) {
        
        
        $personalInfo  = array(); // doctor personal information
        $doctor = array();  // doctor job info
        $clinic = array(); // clinic information
        $result = array(); // for final result and it will be sent as a response to android studio 
        
        
        while($raw = mysqli_fetch_assoc($r)){
            
                // check if result != null because sql may be return $raw['key'] = NULL ; because the left outer statement;
                if($raw['CLINICS_ID'] != NULL){
                
                
                
            // adding doctor personal info 
                
                $personalInfo['NAME'] = $raw['NAME'];
                $personalInfo['IMAGE'] =base64_encode($raw['IMAGE']);
                $personalInfo['VILLAGE'] =  $raw['VILLAGE'];
                $personalInfo['CITY'] =   $raw['CITY'];
                $personalInfo['gov_name'] =   $raw['gov_name'];
                $personalInfo['ROLE'] = $raw['ROLE'];
                $personalInfo['password'] = $raw['password'];
                $personalInfo['PHONE'] = $raw['uname'];
            
            
            // adding doctor job information
                
                $doctor['DOCTOR_ID'] = $raw['DOCTOR_ID'];
                $doctor['EXPERIENCE_YEARS'] = $raw['EXPERIENCE_YEARS'];
                $doctor['TEXT'] = $raw['TEXT'];
                $doctor['DEGREE_TEXT'] = $raw['DEGREE_TEXT'];
                $doctor['COUNT'] = $raw['COUNT'];
                $doctor['RATE_VALUE'] = $raw['RATE_VALUE'];
                $doctor['info'] = $personalInfo ;
            
            
            // adding clinic data 
            
                $clinic['CLINICS_ID'] = $raw['CLINICS_ID'];
                $clinic['PHONE'] = $raw['PHONE'];
                $clinic['BOOKING_PRICE'] = $raw['BOOKING_PRICE'];
                $clinic['ADDRESS'] = $raw['ADDRESS'];
                $clinic['SERVICE_ID'] = $raw['SERVICE_ID'];
                $clinic['USER_ID'] = $raw['USER_ID'];
                
                
                
                $clinic['SERVICE_TEXT'] =$raw['SERVICE_TEXT']  ;
                
            
                $clinic['doctor'] = $doctor;
                
                
            
                array_push($result, $clinic);
    
                
                //  array_push($result, $raw);
                }
        }
        
      $response['code']=1;
      $response['message']= "";
      $response['response']= $result;
        
    
    }else{
    
         $response['code'] =0;
         $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ";
	 $response['message'] = "حدث خطأ  من السيرفر يرجي إبلاغنا ".mysqli_error($con); 


            // echo "Error Occuerd ! ".mysqli_error($con); 
    }


}else{
  $response['code'] =0;
  $response['message'] = "يرجي اختيار التخصص";
}

ob_end_clean();
echo json_encode($response);